#coding=utf-8
from selenium import webdriver
import unittest, time
import xml.dom.minidom
#引入 xml 文件
dom = xml.dom.minidom.parse('/Users/yanlingli/Documents/jiekouzidonghua/entrytask/data/info.xml')
root = dom.documentElement

#url
uu=dom.getElementsByTagName('url')
geturl=uu[0].firstChild.data
#url
def url(self):
    return geturl