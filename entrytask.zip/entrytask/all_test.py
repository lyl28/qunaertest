#coding=utf-8
import unittest
import testcase.singletrip, testcase.roundtrip
testunit=unittest.TestSuite()

testunit.addTest(unittest.makeSuite(testcase.singletrip.Testsingle))
testunit.addTest(unittest.makeSuite(testcase.roundtrip.Testround))

runner = unittest.TextTestRunner()
runner.run(testunit)
