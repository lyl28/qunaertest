# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
import unittest, time, re

class Testsingle(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        self.base_url = "https://www.qunar.com/"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_(self):
        driver = self.driver
        driver.get(self.base_url )
        driver.find_element_by_id("js_searchtype_oneway").click()
        driver.find_element_by_name("fromCity").click()
        driver.find_element_by_name("fromCity").clear()
        driver.find_element_by_name("fromCity").send_keys(u'武汉')
        driver.find_element_by_name("toCity").clear()
        driver.find_element_by_name("toCity").send_keys(u'深圳')
        driver.find_element_by_css_selector("button.button-search").click()

    def is_element_present(self, how, what):
        try: self.driver.find_element(by=how, value=what)
        except NoSuchElementException, e: return False
        return True

    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()

